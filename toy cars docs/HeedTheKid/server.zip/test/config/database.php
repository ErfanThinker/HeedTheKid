<?php
class Database{
 
    // specify your own database credentials
    private $host = "localhost";
    private $db_name = "heed_the_kid";
    private $username = "root";
    private $password = "";
    public $conn;
 
    // get the database connection
    public function getConnection(){
 
        $this->conn = null;
 
        try{
            $this->conn = new PDO("mysql:host={$this->host};dbname={$this->db_name};charset=utf8mb4", $this->username, $this->password);
            $query = "SHOW TABLES FROM {$this->db_name};";
            
            $result = $this->conn->prepare($query)->execute();

            if (!$result) {
                echo "DB Error, could not connect\n";
                exit;
            }
            

        } catch(PDOException $exception){
            echo "Connection error: " . $exception->getMessage();
        }
 
        return $this->conn;
    }

    public  function getTables() {
        if ($this->conn != null) {
            $query = "SHOW TABLES FROM {$this->db_name};";
            
            $result = $this->conn->prepare($query);
            $result->execute();
            if (!$result) {
                echo "DB Error, could not list tables\n";
                exit;
            } else {
               while ($row = $result -> fetch(PDO::FETCH_ASSOC)) {
                    // var_dump($row);
                    echo "Table: {$row["Tables_in_heed_the_kid"]}\n";
                }

            }
        }
    }
}
?>