<?php

    class DeviceContract {
        public static $firebase_token = "firebase_token";
        public static $uuid = "uuid";
        public static $operating_system  = "operating_system";
        public static $os_version = "os_version";
        public static $data = "data";
    }

    class ChildInfoContracts {
        public static $child_name = "child_name";
        public static $child_age = "child_age";
        public static $phone = "phone";
        public static $email = "email";
        public static $gender = "gender";
        public static $autism_relative = "autism_relative";
        public static $records = "records";
    }

    class RecordsContracts {
        public static $device_record_id = "id";
        public static $ac_x = "ac_x";
        public static $ac_y = "ac_y";
        public static $ac_z = "ac_z";
        public static $battery = "battery";
        public static $encoder_1 = "encoder1";
        public static $encoder_2 = "encoder2";
        public static $car_time = "car_time";
        public static $universal_time = "universal_time";
        public static $session_id = "session_id";
    }

?>