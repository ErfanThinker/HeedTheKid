<?php

	class ChildInfo {
        // database connection and table name
        private $conn;
        private $table_name = "child_info";

        public $child_name = "";
        public $child_age;
        public $phone = "";
        public $email = "";
        public $gender = "";
        public $autism_relative = "";
        public $device_id;

        // constructor with $db as database connection
        public function __construct($db){
            $this->conn = $db;
        }

        // create product
        function create(){
         
            // query to insert record
            $query = "INSERT INTO {$this->table_name}
                    SET
                        child_name=:child_name, child_age=:child_age, phone=:phone, email=:email, gender=:gender, autism_relative=:autism_relative, device_id=:device_id ON DUPLICATE KEY UPDATE child_age=:child_age, email=:email, gender=:gender, autism_relative=:autism_relative;";
         
            // prepare query
            $stmt = $this->conn->prepare($query);
         
            // sanitize
            $this->child_name=htmlspecialchars(strip_tags($this->child_name));
            $this->child_age=htmlspecialchars(strip_tags($this->child_age));
            $this->phone=htmlspecialchars(strip_tags($this->phone));
            $this->email=htmlspecialchars(strip_tags($this->email));
            $this->autism_relative=htmlspecialchars(strip_tags($this->autism_relative));
            $this->gender=htmlspecialchars(strip_tags($this->gender));
            $this->device_id=htmlspecialchars(strip_tags($this->device_id));
         
            // bind values
            $stmt->bindParam(":child_name", $this->child_name);
            $stmt->bindParam(":child_age", $this->child_age);
            $stmt->bindParam(":phone", $this->phone);
            $stmt->bindParam(":email", $this->email);
            $stmt->bindParam(":autism_relative", $this->autism_relative);
            $stmt->bindParam(":gender", $this->gender);
            $stmt->bindParam(":device_id", $this->device_id);
            
            // execute query
            if($stmt->execute()){
                $query = "SELECT id FROM {$this->table_name} WHERE child_name=:child_name AND phone=:phone";
                $result = $this->conn->prepare($query);
                $result->bindParam(":phone", $this->phone);
                $result->bindParam(":child_name", $this->child_name);
                $result -> execute();

                $row = $result->fetch(PDO::FETCH_ASSOC);
                // var_dump($row);
                return $row["id"];
            }
         
            return -1;
             
        }
    }
    
	
?>

