<?php

	class Device {
        // database connection and table name
        private $conn;
        private $table_name = "devices";

        public $firebase_token = "";
        public $uuid = "";
        public $operating_system  = "";
        public $os_version = "";

        // constructor with $db as database connection
        public function __construct($db){
            $this->conn = $db;
        }

        // create product
        function create(){
         
            // query to insert record
            $query = "INSERT INTO {$this->table_name}
                    SET
                        firebase_token=:firebase_token, uuid=:uuid, operating_system=:operating_system, os_version=:os_version ON DUPLICATE KEY UPDATE firebase_token=:firebase_token, os_version=:os_version;";
         
            // prepare query
            $stmt = $this->conn->prepare($query);
         
            // sanitize
            $this->uuid=htmlspecialchars(strip_tags($this->uuid));
            $this->firebase_token=htmlspecialchars(strip_tags($this->firebase_token));
            $this->operating_system=htmlspecialchars(strip_tags($this->operating_system));
            $this->os_version=htmlspecialchars(strip_tags($this->os_version));
         
            // bind values
            $stmt->bindParam(":firebase_token", $this->firebase_token);
            $stmt->bindParam(":uuid", $this->uuid);
            $stmt->bindParam(":operating_system", $this->operating_system);
            $stmt->bindParam(":os_version", $this->os_version);
         
            // execute query
            if($stmt->execute()){
                $query = "SELECT id FROM {$this->table_name} WHERE uuid=:uuid";
                $result = $this->conn->prepare($query);
                $result->bindParam(":uuid", $this->uuid);
                $result -> execute();

                $row = $result->fetch(PDO::FETCH_ASSOC);
                // var_dump($row);
                return $row["id"];
            }
         
            return -1;
             
        }
    }
    
	
?>

