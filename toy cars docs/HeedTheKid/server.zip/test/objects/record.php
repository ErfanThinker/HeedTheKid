<?php

	class Record {
        // database connection and table name
        private $conn;
        private $table_name = "records";

        public $device_record_id;
        public $session_id;
        public $ac_x;
        public $ac_y;
        public $ac_z;
        public $encoder_1;
        public $encoder_2;
        public $car_time;
        public $universal_time;
        public $battery;
        public $child_id;

        // constructor with $db as database connection
        public function __construct($db){
            $this->conn = $db;
        }

        // create product
        function create(){
         
            // query to insert record
            $query = "INSERT IGNORE INTO {$this->table_name}
                    SET
                        device_record_id=:device_record_id, session_id=:session_id, 
                        ac_x=:ac_x, ac_y=:ac_y, ac_z=:ac_z,
                        encoder_1=:encoder_1, encoder_2=:encoder_2, car_time=:car_time,
                        universal_time=:universal_time, battery=:battery, child_id=:child_id";
         
            // prepare query
            $stmt = $this->conn->prepare($query);
         
            // sanitize
            $this->device_record_id=htmlspecialchars(strip_tags($this->device_record_id));
            $this->session_id=htmlspecialchars(strip_tags($this->session_id));
            $this->ac_x=htmlspecialchars(strip_tags($this->ac_x));
            $this->ac_y=htmlspecialchars(strip_tags($this->ac_y));
            $this->ac_z=htmlspecialchars(strip_tags($this->ac_z));
            $this->encoder_1=htmlspecialchars(strip_tags($this->encoder_1));
            $this->encoder_2=htmlspecialchars(strip_tags($this->encoder_2));
            $this->battery=htmlspecialchars(strip_tags($this->battery));
            $this->car_time=htmlspecialchars(strip_tags($this->car_time));
            $this->universal_time=htmlspecialchars(strip_tags($this->universal_time));
            $this->child_id=htmlspecialchars(strip_tags($this->child_id));
         
            // bind values
            $stmt->bindParam(":device_record_id", $this->device_record_id);
            $stmt->bindParam(":session_id", $this->session_id);
            $stmt->bindParam(":ac_x", $this->ac_x);
            $stmt->bindParam(":ac_y", $this->ac_y);
            $stmt->bindParam(":ac_z", $this->ac_z);
            $stmt->bindParam(":encoder_1", $this->encoder_1);
            $stmt->bindParam(":encoder_2", $this->encoder_2);
            $stmt->bindParam(":battery", $this->battery);
            $stmt->bindParam(":car_time", $this->car_time);
            $stmt->bindParam(":universal_time", $this->universal_time);
            $stmt->bindParam(":child_id", $this->child_id);
         
            // execute query
            if($stmt->execute()){
                return true;
            }
         
            return false;
             
        }
    }
    
	
?>

