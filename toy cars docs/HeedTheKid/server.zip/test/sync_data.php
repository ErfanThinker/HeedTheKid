<?php

    // required headers
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    // include database and object files
    include_once(dirname(__FILE__).'/config/database.php');
    include_once(dirname(__FILE__).'/config/jsonContracts.php');
    include_once(dirname(__FILE__).'/objects/device.php');
    include_once(dirname(__FILE__).'/objects/childInfo.php');
    include_once(dirname(__FILE__).'/objects/record.php');
    include_once(dirname(__FILE__).'/helpers/json_handler.php');

    // instantiate database and product object
    $database = new Database();
    $db = $database->getConnection();
    // $database -> getTables();

    // initialize object
    

    function insertDevice($db_con, $os_version, $firebase_token, $uuid, $operating_system) {
        $device = new Device($db_con);

        $device->os_version   = $os_version;
        $device->firebase_token   = $firebase_token;
        $device->uuid   = $uuid;
        $device->operating_system   = $operating_system;
        
        return $device -> create();
    }

    function insertChild($db_con, $child_data, $device_id) {

        if (!isset($child_data[ChildInfoContracts::$child_name]) || !isset($child_data[ChildInfoContracts::$child_age]) 
            || !isset($child_data[ChildInfoContracts::$phone]) || !isset($child_data[ChildInfoContracts::$email])
            || !isset($child_data[ChildInfoContracts::$gender]) || !isset($child_data[ChildInfoContracts::$autism_relative])
            || !isset($child_data[ChildInfoContracts::$records]) || count($child_data) != 7) {

            throw new Exception("Post Parameters are invalid for the child.");

        }

        if(!preg_match("/^[0-9]{3}[0-9]{4}[0-9]{4}$/", $child_data[ChildInfoContracts::$phone])) { //phone validation
          throw new Exception("Phone number not valid!");
        }

        $child_info = new ChildInfo($db_con);
        $child_info->child_name   = $child_data[ChildInfoContracts::$child_name];
        $child_info->child_age   = $child_data[ChildInfoContracts::$child_age];
        $child_info->phone   = $child_data[ChildInfoContracts::$phone];
        $child_info->email   = $child_data[ChildInfoContracts::$email];
        $child_info->gender   = $child_data[ChildInfoContracts::$gender];
        $child_info->autism_relative = $child_data[ChildInfoContracts::$autism_relative];
        $child_info->device_id   = $device_id;

        return $child_info -> create();
    }

    function insertRecord($db_con, $record_data, $child_id) {

        if (!isset($record_data[RecordsContracts::$device_record_id]) || !isset($record_data[RecordsContracts::$session_id])
            || !isset($record_data[RecordsContracts::$ac_x])
            || !isset($record_data[RecordsContracts::$ac_y])|| !isset($record_data[RecordsContracts::$ac_z])
            || !isset($record_data[RecordsContracts::$encoder_1]) || !isset($record_data[RecordsContracts::$encoder_2]) 
            || !isset($record_data[RecordsContracts::$car_time]) || !isset($record_data[RecordsContracts::$universal_time]) 
            || !isset($record_data[RecordsContracts::$battery]) || count($record_data) != 10) {
            
            // throw new Exception("Post Parameters are invalid for one of the records with id:{$record_data["id"]}!");
            throw new Exception("Post Parameters are invalid for one of the records!");

        }

        $record = new Record($db_con);
        $record->device_record_id   = $record_data[RecordsContracts::$device_record_id];
        $record->session_id   = $record_data[RecordsContracts::$session_id];
        $record->ac_x   = $record_data[RecordsContracts::$ac_x];
        $record->ac_y   = $record_data[RecordsContracts::$ac_y];
        $record->ac_z   = $record_data[RecordsContracts::$ac_z];
        $record->encoder_1 = $record_data[RecordsContracts::$encoder_1];
        $record->encoder_2   = $record_data[RecordsContracts::$encoder_2];
        $record->car_time   = $record_data[RecordsContracts::$car_time];
        $record->universal_time   = $record_data[RecordsContracts::$universal_time];
        $record->battery   = $record_data[RecordsContracts::$battery];

        $record->child_id   = $child_id;

        return $record -> create();
    }

	if($_SERVER['REQUEST_METHOD'] != 'POST'){
            
            http_response_code(400);
            echo json_encode(array("error" => "Method should be POST"));

        } else if(!isset($_POST[DeviceContract::$firebase_token]) || !isset($_POST[DeviceContract::$operating_system]) 
            || !isset($_POST[DeviceContract::$os_version]) || !isset($_POST[DeviceContract::$uuid]) 
            || !isset($_POST[DeviceContract::$data]) || count($_POST) != 5){

            http_response_code(400);
            echo json_encode(array("error" => "Post Parameters are invalid."));

        } else {
            try {

                $db->beginTransaction();
                
                $device_insert_result = insertDevice($db, $_POST[DeviceContract::$os_version], $_POST[DeviceContract::$firebase_token],
                $_POST[DeviceContract::$uuid], $_POST[DeviceContract::$operating_system]);

                if ($device_insert_result != -1){
                    
                    foreach (JsonHandler::decode(stripslashes($_POST[DeviceContract::$data])) as $child_data) {
                        
                        

                        $child_insert_result = insertChild($db, $child_data, $device_insert_result);

                        if ($child_insert_result != -1){
                            
                            foreach ($child_data[ChildInfoContracts::$records] as $record) {
                                
                                if (!insertRecord($db, $record, $child_insert_result)) {
                                    throw new Exception("Error in syncing the records!");
                                }

                            }

                        }
                    }

                    
                    
                }

                http_response_code(200);
                echo json_encode(array("operation" => "Sucess!"));
                $db->commit();

            } catch(Exception $e){
                $db->rollBack();
                http_response_code(400);
                echo json_encode(array("error" => $e->getMessage()));

            }
            
    }
    
	
?>

